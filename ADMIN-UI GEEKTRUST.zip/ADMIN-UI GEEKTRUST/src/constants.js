const config = {}
config.PAGE_SIZE = 10


export default config;