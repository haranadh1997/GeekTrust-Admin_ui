# Below is the challenge link, you will find the requirement here



https://www.geektrust.in/coding-problem/frontend/adminui



# The coding Challenge is developed in Visual Studio Code Editior


# Installing  the dependencies


By typing npm install the dependencies will be installed

After dependinces installed type npm start to run the server

After that  type http://locolhost:3000 in your browser to view the output